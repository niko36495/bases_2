
const config = {
    host: 'localhost',
    user: 'root',
    password: 'helen1',
    database: 'soundnest'
};

module.exports = config;

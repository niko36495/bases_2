

CREATE DATABASE IF NOT EXISTS soundnest
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE soundnest;


CREATE TABLE IF NOT EXISTS `User` (
    user_id INT UNSIGNED AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    email VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    birth_date DATE,
    is_admin BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (user_id),
    UNIQUE KEY uq_user_email (email)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS Subscription (
    subscription_id INT UNSIGNED AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,

    plan_name VARCHAR(50) NOT NULL,
    plan_description VARCHAR(255),
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    duration_days SMALLINT UNSIGNED,

    start_date DATE NOT NULL,
    end_date DATE,

    status ENUM(
        'pending',
        'active',
        'expired',
        'cancelled'
    ) NOT NULL DEFAULT 'pending',

    PRIMARY KEY (subscription_id),

    KEY idx_subscription_user (user_id),

    CONSTRAINT chk_subscription_price
        CHECK (price >= 0),

    CONSTRAINT chk_subscription_duration
        CHECK (duration_days IS NULL OR duration_days > 0),

    CONSTRAINT chk_subscription_dates
        CHECK (end_date IS NULL OR end_date >= start_date),

    CONSTRAINT fk_subscription_user
        FOREIGN KEY (user_id)
        REFERENCES `User`(user_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS Artist (
    artist_id INT UNSIGNED AUTO_INCREMENT,
    stage_name VARCHAR(150) NOT NULL,
    biography TEXT,
    country VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (artist_id)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS Album (
    album_id INT UNSIGNED AUTO_INCREMENT,
    artist_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    release_date DATE,
    cover_url VARCHAR(500),

    PRIMARY KEY (album_id),

    KEY idx_album_artist (artist_id),

    CONSTRAINT fk_album_artist
        FOREIGN KEY (artist_id)
        REFERENCES Artist(artist_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS Song (
    song_id INT UNSIGNED AUTO_INCREMENT,
    album_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    duration_seconds INT UNSIGNED NOT NULL,
    genre VARCHAR(80),
    audio_url VARCHAR(500),
    cover_url VARCHAR(500),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (song_id),

    KEY idx_song_album (album_id),

    CONSTRAINT chk_song_duration
        CHECK (duration_seconds > 0),

    CONSTRAINT fk_song_album
        FOREIGN KEY (album_id)
        REFERENCES Album(album_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS Playlist (
    playlist_id INT UNSIGNED AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    cover_url VARCHAR(500),

    playlist_type ENUM(
        'standard',
        'liked_songs'
    ) NOT NULL DEFAULT 'standard',

    visibility ENUM(
        'public',
        'private'
    ) NOT NULL DEFAULT 'private',

    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    liked_user_id INT UNSIGNED
        GENERATED ALWAYS AS (
            CASE
                WHEN playlist_type = 'liked_songs'
                THEN user_id
                ELSE NULL
            END
        ) STORED,

    PRIMARY KEY (playlist_id),

    UNIQUE KEY uq_playlist_user_name (user_id, name),

    -- Allows only one Liked Songs playlist per user.
    -- Multiple NULL values are allowed for standard playlists.
    UNIQUE KEY uq_playlist_liked_user (liked_user_id),

    KEY idx_playlist_user (user_id),

    CONSTRAINT fk_playlist_user
        FOREIGN KEY (user_id)
        REFERENCES `User`(user_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;



CREATE TABLE IF NOT EXISTS PlaylistSong (
    playlist_id INT UNSIGNED NOT NULL,
    song_id INT UNSIGNED NOT NULL,
    added_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    position INT UNSIGNED NOT NULL,

    PRIMARY KEY (playlist_id, song_id),

    UNIQUE KEY uq_playlist_position (playlist_id, position),

    KEY idx_playlistsong_song (song_id),

    CONSTRAINT fk_playlistsong_playlist
        FOREIGN KEY (playlist_id)
        REFERENCES Playlist(playlist_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_playlistsong_song
        FOREIGN KEY (song_id)
        REFERENCES Song(song_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;



CREATE TABLE IF NOT EXISTS Review (
    review_id INT UNSIGNED AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    song_id INT UNSIGNED NOT NULL,
    rating TINYINT UNSIGNED NOT NULL,
    comment TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (review_id),

    UNIQUE KEY uq_review_user_song (user_id, song_id),

    KEY idx_review_song (song_id),

    CONSTRAINT chk_review_rating
        CHECK (rating BETWEEN 1 AND 5),

    CONSTRAINT fk_review_user
        FOREIGN KEY (user_id)
        REFERENCES `User`(user_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_review_song
        FOREIGN KEY (song_id)
        REFERENCES Song(song_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;


CREATE TRIGGER trg_user_create_liked_songs
AFTER INSERT ON `User`
FOR EACH ROW
BEGIN
    INSERT INTO Playlist (
        user_id,
        name,
        description,
        playlist_type,
        visibility
    )
    VALUES (
        NEW.user_id,
        'Liked Songs',
        'Songs saved as favorites by the user',
        'liked_songs',
        'private'
    );
END//



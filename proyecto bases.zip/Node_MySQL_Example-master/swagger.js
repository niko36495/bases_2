
const swaggerJsdoc = require("swagger-jsdoc");

const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "SoundNest API",
      version: "1.0.0",
      description:
        "Documentación de la API de SoundNest desarrollada con Node.js, Express y MySQL."
    },
    servers: [
      {
        url: "http://localhost:5000",
        description: "Servidor local de desarrollo"
      }
    ],
    tags: [
      { name: "Auth", description: "Autenticación" },
      { name: "Users", description: "Gestión de usuarios" },
      { name: "Albums", description: "Álbumes" },
      { name: "Songs", description: "Canciones" },
      { name: "Playlists", description: "Listas de reproducción" },
    ]
  },
  apis: ["./routes/*.js"]
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = swaggerSpec;

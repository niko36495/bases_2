
const express = require("express");
const router = express.Router();
const testDao = require("../dao/test.dao");

/**
 * @swagger
 * tags:
 *   name: SoundNest Music
 *   description: Operaciones musicales de SoundNest
 */

/**
 * @swagger
 * /test:
 *   get:
 *     summary: Obtener todas las canciones
 *     tags: [SoundNest Music]
 *     responses:
 *       200:
 *         description: Lista de canciones obtenida correctamente
 *       500:
 *         description: Error del servidor o de la base de datos
 */
router.get("/", testDao.getSongs);

/**
 * @swagger
 * /test/albums:
 *   get:
 *     summary: Obtener todos los álbumes
 *     tags: [SoundNest Music]
 *     responses:
 *       200:
 *         description: Lista de álbumes obtenida correctamente
 *       500:
 *         description: Error del servidor o de la base de datos
 */
router.get("/albums", testDao.getAlbums);

/**
 * @swagger
 * /test:
 *   post:
 *     summary: Crear una canción
 *     tags: [SoundNest Music]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - title
 *               - artist
 *               - album
 *               - duration
 *             properties:
 *               title:
 *                 type: string
 *                 example: Test Song
 *               artist:
 *                 type: string
 *                 example: Test Artist
 *               album:
 *                 type: string
 *                 example: Test Album
 *               genre:
 *                 type: string
 *                 example: Pop
 *               duration:
 *                 type: integer
 *                 example: 210
 *               audioUrl:
 *                 type: string
 *                 example: https://example.com/song.mp3
 *               coverUrl:
 *                 type: string
 *                 example: https://example.com/cover.jpg
 *     responses:
 *       201:
 *         description: Canción creada correctamente
 *       400:
 *         description: Datos incompletos o inválidos
 *       500:
 *         description: Error del servidor o de la base de datos
 */
router.post("/", testDao.createSong);

module.exports = router;
